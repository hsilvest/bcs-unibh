#include "glut.h"

#include <iostream>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>

static int ano1 = 0, dia1 = 0, ano2 = 0, dia2 = 0, sol = 0, apagado = true;
static float limiteVolume = 20.0;
GLdouble rotacao, angulo = 10.0, cameraEmX = 1.0, cameraEmY = 1.0, cameraEmZ = 5.0;

void teclado (unsigned char key, int x, int y) {
     switch (key) {
          case 'l':
               apagado = !apagado;
               if (apagado) {
                   glDisable(GL_LIGHT0);
               } else {
                   glEnable(GL_LIGHT0);
               }
               break;
          case 'q':
               dia1 = (dia1 + 7) % 360;
               break;
          case 'w':
               ano1 = (ano1 + 5) % 360;
               break;
          case 'e':
               dia2 = (dia2 + 10) % 360;
               break;
          case 'r':
               ano2 = (ano2 + 7) % 360;
               break;
          case 't':
               sol = (sol + 5) % 360;
               break;
          default:
               break;
     }
     glutPostRedisplay();
}

void setasDirecao(int tecla, int x, int y) {
     switch(tecla) {
          case GLUT_KEY_UP: /* Seta para Cima */
               if (cameraEmZ < limiteVolume) {
                    cameraEmZ = cameraEmZ + 1.0;
               }
               glutPostRedisplay();
               break;
          case GLUT_KEY_DOWN: /* Seta para Baixo */
               if (cameraEmZ > -limiteVolume) {
                    cameraEmZ = cameraEmZ - 1.0;
               }
               glutPostRedisplay();
               break;
          default:
               break;
     }
}

void Inicializar(void) {
     GLfloat luzAmbiente[4]={0.2,0.2,0.2,1.0}; 
	 GLfloat luzDifusa[4]={0.7,0.7,0.7,1.0}; // "cor" 
	 GLfloat luzEspecular[4]={1.0, 1.0, 1.0, 1.0}; // "brilho" 
	 GLfloat posicaoLuz[4]={10.0, 10.0, 1.0, 1.0}; // Estabelecer/Variar o posicionamento da luz
     
     // Especifica que a cor de fundo da janela ser� preta
     glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
     glShadeModel (GL_FLAT);
     
     // Capacidade de brilho do material
	 GLfloat especularidade[4]={1.0,1.0,1.0,1.0}; 
	 GLint especMaterial = 60;
     
     // Habilita o modelo de coloriza��o de Gouraud
	 glShadeModel(GL_SMOOTH);

	 // Define a reflet�ncia do material
	 glMaterialfv(GL_FRONT,GL_SPECULAR, especularidade);
	 // Define a concentra��o do brilho
     glMateriali(GL_FRONT,GL_SHININESS,especMaterial);

	 // Ativa o uso da luz ambiente 
	 glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente);

	 // Define os par�metros da luz de n�mero 0
	 glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente); 
	 glLightfv(GL_LIGHT0, GL_DIFFUSE, luzDifusa );
	 glLightfv(GL_LIGHT0, GL_SPECULAR, luzEspecular );
	 glLightfv(GL_LIGHT0, GL_POSITION, posicaoLuz );

	 // Habilita a defini��o da cor do material a partir da cor corrente
	 glEnable(GL_COLOR_MATERIAL); // Usar as cores correntes para colorir os materiais percept�veis no escuro
	 //Habilita o uso de ilumina��o
	 glEnable(GL_LIGHTING); // Declara ilumina��o
	 // Habilita a luz de n�mero 0
	 //glEnable(GL_LIGHT0); // Usa ilumina��o na luz/l�mpada 0
	 // Habilita o depth-buffering
	 glEnable(GL_DEPTH_TEST); // Faz a luz preencher todo o buffer de pronfundidade e n�o s� o fundo
}

void atualizaCamera() {
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();
     gluPerspective(60.0, 1.0, 0.5, limiteVolume);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity(); 
     gluLookAt(cameraEmX, cameraEmY, cameraEmZ, 0.0,0.0,0.0, 0.0,1.0,0.0);
}

void desenhar(void) {
     glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     glColor3f (1.0, 1.0, 1.0);
     atualizaCamera();
     
     glRotatef ((GLfloat) sol, 0.0, 1.0, 0.0);
     glColor3f (1.0, 1.0, 0.0); // Cor para o sol
     glutSolidSphere(1.0, 40, 40); // Desenha o sol
          
     glRotatef ((GLfloat) ano1, 0.0, 1.0, 0.0);
     glTranslatef (2.0, 0.0, 0.0);
     glRotatef ((GLfloat) dia1, 0.0, 1.0, 0.0);
     glColor3f (0.0, 0.0, 1.0); // Cor para o primeiro planeta
     glutSolidSphere(0.4, 30, 30); // Desenha o planeta

     glRotatef ((GLfloat) ano2, 0.0, 1.0, 0.0);
     glTranslatef (3.0, 0.0, 0.0);
     glRotatef ((GLfloat) dia2, 0.0, 1.0, 0.0);
     glColor3f (1.0, 0.0, 0.0); // Cor para o segundo planeta
     glutSolidSphere(0.3, 30, 30); // Desenha o planeta
     
     glutSwapBuffers();
}

void remodelar (int w, int h) {
     glViewport (0, 0, (GLsizei) w, (GLsizei) h);
     glMatrixMode (GL_PROJECTION);
     glLoadIdentity ();
     gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 20.0);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();
     gluLookAt (cameraEmX,cameraEmY,cameraEmZ, 0.0,0.0,0.0, 0.0,1.0,0.0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Terceiro Projeto");
    Inicializar ();
    glutDisplayFunc(desenhar);
    glutReshapeFunc(remodelar);
    glutKeyboardFunc(teclado);
    glutSpecialFunc(setasDirecao);
    glutMainLoop();
    return 0;
}

