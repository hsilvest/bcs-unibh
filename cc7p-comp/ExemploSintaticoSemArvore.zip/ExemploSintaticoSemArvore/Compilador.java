public class Compilador {

	public static void main(String [] entrada) {

		Lexico analisadorLexico = new Lexico("programa.txt");
		Sintatico analisadorSintatico = new Sintatico(analisadorLexico);
		
		analisadorSintatico.Programa();	
	    analisadorSintatico.fechaArquivos();
	    System.out.println("Compilação de Programa Realizada!");
	}

}
