public class Sintatico {

	private Lexico lexico;
	private Token token;

	public Sintatico(Lexico lexico) {

		this.lexico = lexico;
	}

	// Fecha os arquivos de entrada e de tokens
	public void fechaArquivos() {

		lexico.fechaArquivo();
	}

	public void erroSintatico(String mensagem) {

		System.out.println("\nErro sintatico na linha " + token.getLinha() + " e coluna " + token.getColuna() + ":\n");
		System.out.println(mensagem + "\n");
		token = lexico.proxToken();
	}

	public boolean casaToken(int numeroToken) {

		if (token.getClasse() == numeroToken) {
			token = lexico.proxToken();
			return true;
		} else {
			return false;
		}
	}

	public void Programa() {

		token = lexico.proxToken(); // Leitura inicial obrigatoria do primeiro
		
		Classe();
		if (!casaToken(Token.EOF)) {
			erroSintatico("Esperado final de arquivo, encontrado " + token.getLexema());
		}
	}
	
	public void Classe() {
		
		if (!casaToken(Token.PUBLIC)) {
			erroSintatico("Esperado public, encontrado " + token.getLexema());
		}
		if (!casaToken(Token.CLASS)) {
			erroSintatico("Esperado class, encontrado " + token.getLexema());
		}
		
		if (!casaToken(Token.ID)) {
			erroSintatico("Esperado um identificador, encontrado " + token.getLexema());
		}
		if (!casaToken(Token.ABRE_CHAVES)) {
			erroSintatico("Esperado {, encontrado " + token.getLexema());
		}
		Comando();
		if (!casaToken(Token.FECHA_CHAVES)) {
			erroSintatico("Esperado }, encontrado " + token.getLexema());
		}
	}
	
	public void Comando() {
		
		if (casaToken(Token.COUT)) {
			if (casaToken(Token.MENOR_MENOR)) {
				E();
				if (!casaToken(Token.PONTO_VIRGULA)) {
					erroSintatico("Esperado ;, encontrado " + token.getLexema());
				}
			}
			else {
				erroSintatico("Esperado <<, encontrado " + token.getLexema());
			}
		}
		else {
			erroSintatico("Esperado cout, encontrado " + token.getLexema());
		}
	}
	
	public void E() {
		
		T();
		Elinha();
	}
	
	public void Elinha() {
		
		if (casaToken(Token.MAIS)) {
			T();
			Elinha();
		}
	}
	
	public void T() {
		
		F();
		Tlinha();
	}
	
	public void Tlinha() {
		
		if (casaToken(Token.VEZES)) {
			F();
			Tlinha();
		}
	}
	
	public void F() {

		if (!casaToken(Token.ID) & !casaToken(Token.CONST_INT)) {
			erroSintatico("Esperado identificador ou constante inteira, encontrado " + token.getLexema());
		}
	}
}
