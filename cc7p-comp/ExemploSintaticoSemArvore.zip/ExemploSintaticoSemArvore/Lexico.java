import java.io.*;
import java.util.Hashtable;

public class Lexico {

	private static final int FINAL	= -1;
	private static int lido			= 0; // Variavel armazena o último caractere lido do arquivo
	private static int linha		= 0;
	private static int coluna		= 0;

	private RandomAccessFile arquivo;
	
	public static Hashtable<String,Token> tabela;

	public Lexico(String entrada) {
		
        // Abre arquivo de entrada
		try {
			arquivo = new RandomAccessFile(entrada, "r");
			tabela = new Hashtable<String,Token>();
			
			tabela.put("public", new Token(Token.PUBLIC, "public", 0, 0));
			tabela.put("class", new Token(Token.CLASS, "class", 0, 0));
			tabela.put("cout", new Token(Token.COUT, "cout", 0, 0));
		}
		catch(IOException erroArquivo) {
			System.out.println("Erro de abertura do arquivo " + entrada);
			System.exit(1);
		}
		catch(Exception erroGeral) {
			System.out.println("Erro do programa ou falha da tabela de simbolos");
			System.exit(2);
		}
	}

	// Fecha arquivo de entrada
	public void fechaArquivo() {

		try {
			arquivo.close();
		}
		catch (IOException erroArquivo) {
			System.out.println ("Erro ao fechar arquivo");
			System.exit(3);
		}
	}

	//Reporta erro para o usuário
	public void erroLexico(String mensagem) {

		System.out.println("Erro lexico: " + mensagem + "\n");
	}

    //Volta uma posição do carro de leitura
	public void retornaPonteiro(){
		
		try {
			// Não é necessário retornar o ponteiro em caso de Fim de Arquivo
			if (lido != FINAL) {
				arquivo.seek(arquivo.getFilePointer() - 1);
			}   
		}
		catch(IOException e) {
			System.out.println("Falha ao retornar a leitura");
			System.exit(4);
		}
	}

	// Obtém próximo token
	public Token proxToken() {

		StringBuilder lexema = new StringBuilder();
		int estado = 0;
		char c = ' ';
		
		while(true) {
			try {
				lido = arquivo.read();
				coluna++;
				if(lido != FINAL) {
					c = (char) lido;
				}
				if(c == '\n') {
					linha++;
				}
			}
			catch(IOException e) {
				System.out.println("Erro na leitura do arquivo");
				System.exit(3);
			}
			switch(estado) {
				case 0:
					if (lido == FINAL) { // Estado 01
						return new Token(Token.EOF, "EOF", linha, coluna);
					}
					else if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
						// Permance no estado = 0
					}
					else if (Character.isDigit(c)){
						lexema.append(c);
						estado = 1;
					}
					else if (Character.isLetter(c)) {
						lexema.append(c);
						estado = 3;
					}
					else if (c == '<') {
						estado = 5;
					}
					else if (c == '{') {
						// Estado 7
						return new Token(Token.ABRE_CHAVES, "{", linha, coluna);
					}
					else if (c == '}') {
						// Estado 8
						return new Token(Token.FECHA_CHAVES, "}", linha, coluna);
					}
					else if (c == '+') {
						// Estado 9
						return new Token(Token.MAIS, "+", linha, coluna);
					}
					else if (c == '*') {
						// Estado 10
						return new Token(Token.VEZES, "*", linha, coluna);
					}
					else if (c == ';') {
						// Estado 11
						return new Token(Token.PONTO_VIRGULA, ";", linha, coluna);
					}
					else if (c == '/') {
						estado = 12;
					}
					else {
						erroLexico("Caractere Invalido: " + c);
						return null;
					}
					break;
				case 1:
					if (lido != FINAL && Character.isDigit(c)) {
						lexema.append(c);
						// Permanece no estado = 1
					}
					else { // Estado 02
						retornaPonteiro();						
						return new Token(Token.CONST_INT, lexema.toString(), linha, coluna);
					}
					break;
				case 3:
					if (lido != FINAL && (c == '_' || Character.isLetterOrDigit(c))) {
						lexema.append(c);
						// Permanece no estado = 3
					}
					else { // Estado 04
						retornaPonteiro();
						Token token = tabela.get(lexema.toString());
						if (token == null) {
							return new Token(Token.ID, lexema.toString(), linha, coluna);
						}
						token.setLinha(linha);
						token.setColuna(coluna);
						return token;
					}
					break;
				case 5:
					if (lido != FINAL && c == '<') { // Estado 5
						return new Token(Token.MENOR_MENOR, "<<", linha, coluna);
					}
					else { // Estado 6
						retornaPonteiro();
						return new Token(Token.MENOR, "<", linha, coluna);
					}
				case 12:
					if (lido != FINAL && c == '*') {
						estado = 13;
					}
					else {
						retornaPonteiro();
						erroLexico("O comentario deve ser berto com /*");
						return null;
					}
					break;
				case 13:
					if (lido != FINAL && c == '*') {
						estado = 14;
					} else if (lido == FINAL) {
						erroLexico("O comentario deve ser fechada com */ antes do fim de arquivo");
						return null;
					} // Se vier outro, permanece no estado = 12
					break;
				case 14:
					if (lido == FINAL) {
						erroLexico("O comentario deve ser fechada com */ antes do fim de arquivo");
						return null;
					}
					else if (c == '/') {
						estado = 0;
					}
					else {
						estado = 13;
					}
					break;
			}
		}
	}
}
