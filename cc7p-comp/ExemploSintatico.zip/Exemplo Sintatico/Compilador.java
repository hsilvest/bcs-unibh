public class Compilador {

	public static void main(String [] entrada) {

		Lexico analisadorLexico = new Lexico(entrada [0]);
		Sintatico analisadorSintatico = new Sintatico(analisadorLexico);
		
		analisadorSintatico.programa();	
	    analisadorSintatico.fechaArquivos();
	}

}
