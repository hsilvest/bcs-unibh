public class Token {
	
	public final static int EOF			= 1;
	public final static int ID 			= 2;
	public final static int CONST_INT		= 3;
	public final static int MENOR_IGUAL	= 4;
	public final static int MENOR			= 5;
	public final static int IGUAL			= 6;
	public final static int DIFERENTE		= 7;
	public final static int ABRE_CHAVES	= 8;
	public final static int FECHA_CHAVES	= 9;
	
	public final static int IF			= 22;
	public final static int THEN			= 24;
	public final static int ELSE			= 24;
	
	private String lexema;
	private int classe;
	private int linha;
	private int coluna;
	
	public Token(int classe, String lexema, int linha, int coluna) {
		
		this.classe = classe;
		this.lexema = lexema;
		this.linha = linha;
		this.coluna = coluna;
	}

	public int getClasse() {
		
		return classe;
	}
	
	public void setClasse(int classe) {
		
		this.classe = classe;
	}
	
	public String getLexema() {
		
		return lexema;
	}
	
	public void setLexema(String lexema) {
		
		this.lexema = lexema;
	}
	
	public int getLinha() {
		return linha;
	}

	public void setLinha(int linha) {
		this.linha = linha;
	}

	public int getColuna() {
		return coluna;
	}

	public void setColuna(int coluna) {
		this.coluna = coluna;
	}
	
	public String toString() {
		return "Token: " + classe + " / Lexema: " + lexema + " (linha + " + linha + " e coluna " + coluna + ")\n";
	}
}
