import java.io.*;

public class Sintatico {

	private static BufferedWriter arquivoArvore;
	private Lexico lexico;
	private Token lido;

	public Sintatico(Lexico lexico) {

		try {
			arquivoArvore = new BufferedWriter(new FileWriter("arvore"));
			this.lexico = lexico;
		} catch (IOException erroArquivo) {
			System.out.println("Erro de abertura do arquivo saida");
			System.exit(1);
		} catch (Exception erroGeral) {
			System.out.println("Erro do programa ou falha na instancia do analisador lexico");
			System.exit(2);
		}
	}

	// Fecha os arquivos de entrada e de tokens
	public void fechaArquivos() {

		try {
			lexico.fechaArquivo();
			arquivoArvore.flush();
			arquivoArvore.close();
		} catch (IOException erroArquivo) {
			System.out.println("Erro ao fechar arquivo");
			System.exit(3);
		}
	}

	public void erro(String mensagem) {

		System.out.println("\nErro sintatico na linha " + lido.getLinha() + " e coluna " + lido.getColuna() + ":\n");
		System.out.println(mensagem + "\n");
		lido = lexico.proxToken();
	}

	public boolean casaToken(int numeroToken) {

		if (lido.getClasse() == numeroToken) {
			lido = lexico.proxToken();
			return true;
		} else {
			return false;
		}
	}

	public void programa() {

		lido = lexico.proxToken(); // Leitura inicial obrigatoria do primeiro

		if (!casaToken(Token.EOF)) {
			erro("Esperado final de arquivo, encontrado " + lido.getLexema());
		}
	}
}
