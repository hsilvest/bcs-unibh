import java.io.*;

public class Lexico {

	private static final int FINAL = -1;
	private static int lido = 0; // Variavel armazena o último caractere lido do arquivo
	private static int linha = 0;
	private static int coluna = 0;

	private RandomAccessFile arquivo;

	public Lexico(String entrada) {
		
        // Abre arquivo de entrada
		try {
			arquivo = new RandomAccessFile(entrada, "r");
		}
		catch(IOException erroArquivo) {
			System.out.println("Erro de abertura do arquivo " + entrada);
			System.exit(1);
		}
		catch(Exception erroGeral) {
			System.out.println("Erro do programa ou falha da tabela de simbolos");
			System.exit(2);
		}
	}

	// Fecha arquivo de entrada
	public void fechaArquivo() {

		try {
			arquivo.close();
		}
		catch (IOException erroArquivo) {
			System.out.println ("Erro ao fechar arquivo");
			System.exit(3);
		}
	}

	//Reporta erro para o usuário
	public void sinalizaErro(String mensagem) {

		System.out.println("Erro lexico: " + mensagem + "\n");
	}

    //Volta uma posição do carro de leitura
	public void retornaPonteiro(){
		
		try {
			// Não é necessário retornar o ponteiro em caso de Fim de Arquivo
			if (lido != FINAL) {
				arquivo.seek(arquivo.getFilePointer() - 1);
			}   
		}
		catch(IOException e) {
			System.out.println("Falha ao retornar a leitura");
			System.exit(4);
		}
	}

	// Obtém próximo token
	public Token proxToken() {

		StringBuilder lexema = new StringBuilder();
		int estado = 0;
		char c = ' ';
		
		while(true) {
			try {
				lido = arquivo.read();
				linha++;
				if(lido != FINAL) {
					c = (char) lido;
				}
				if(c == '\n') {
					coluna++;
				}
			}
			catch(IOException e) {
				System.out.println("Erro na leitura do arquivo");
				System.exit(3);
			}
			switch(estado) {
				case 0:
					if (lido == FINAL) { // Estado 01
						return new Token(Token.EOF, "EOF", linha, coluna);
					}
					else if (c == ' ' || c == '\n' || c == '\r') {
						// Permance no estado = 0
					}
					else if (Character.isLetter(c)){
						lexema.append(c);
						estado = 8;
					}
					else if (Character.isDigit(c)) {
						lexema.append(c);
						estado = 6;
					}
					else if (c == '<') {
						estado = 10;
					}
					else if (c == '=') {
						estado = 2;
					}
					else if (c == '!') {
						estado = 4;
					}
					else if (c == '/') {
						estado = 16;
					}
					else {
						sinalizaErro("Caractere Invalido: " + c);
						return null;
					}
					break;
				case 2:
					if (lido != FINAL && c == '=') { // Estado 3
						return new Token(Token.IGUAL, "==", linha, coluna);
					}
					else {
						retornaPonteiro();
						sinalizaErro("Token incompleto para o caractere =");
					}
					break;
				case 4:
					if (lido != FINAL && c == '=') { // Estado 5
						return new Token(Token.DIFERENTE, "!=", linha, coluna);
					}
					else {
						retornaPonteiro();
						sinalizaErro("Token incompleto para o caractere !");
					}
					break;
				case 6:
					if (lido != FINAL && Character.isDigit(c)) {
						lexema.append(c);
						// Permanece no estado = 6
					}
					else { // Estado 07
						retornaPonteiro();						
						return new Token(Token.CONST_INT, lexema.toString(), linha, coluna);
					}
					break;
				case 8:
					if (lido != FINAL && (c == '_' || Character.isLetterOrDigit(c))) {
						lexema.append(c);
						// Permanece no estado = 8
					}
					else { // Estado 09
						retornaPonteiro();
						return new Token(Token.ID, lexema.toString(), linha, coluna);
					}
					break;
				case 10:
					if (lido != FINAL && c == '=') { // Estado 24
						return new Token(Token.MENOR_IGUAL, "<=", linha, coluna);
					}
					else { // Estado 12
						retornaPonteiro();
						return new Token(Token.MENOR, "<", linha, coluna);
					}
				case 16:
					if (lido != FINAL && c == '*') {
						estado = 17;
					}
					else {
						retornaPonteiro();
						sinalizaErro("O comentario deve ser fechado com */ antes do fim de arquivo");
						return null;
					}
					break;
				case 17:
					if (lido != FINAL && c == '*') {
						estado = 18;
					} else if (lido == FINAL) {
						sinalizaErro("O comentario deve ser fechada com */ antes do fim de arquivo");
						return null;
					} // Se vier outro, permanece no estado = 17
					break;
				case 18:
					if (lido == FINAL) {
						sinalizaErro("O comentario deve ser fechada com */ antes do fim de arquivo");
						return null;
					}
					else if (c == '/') {
						estado = 0;
					}
					else {
						estado = 17;
					}
					break;
			}
		}
	}
}
