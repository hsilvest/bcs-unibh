%   Dayanne Gouveia Coelho
%	UNIBH - Departamento de Ciencias Exatas e Tecnol�gicas
%	e-mail: dayanne.coelho@prof.unibh.br

function  result_bissecao = bissecao(fname,a,b,epsilon, IterMax)

   fa = feval(fname,a);
   iter = 1;
   erro = 1000;
   result_bissecao=[0 0 0 0 0];
  while ( (erro >  epsilon)  && (iter < IterMax) )
     x  = ( b + a )/2;
     fx = feval(fname,x); 
     result_bissecao(iter+1,:) = [a,b,x,fx,erro];
     if ( (fx*fa) < 0.0 )
        b = x;
     else
         a = x;
         fa = fx;
     end
     erro = abs(result_bissecao(iter+1,3) - result_bissecao(iter,3) );
     iter = iter + 1;
  end
  
   
