%   Dayanne Gouveia Coelho
%	UNIBH - Departamento de Ciencias Exatas e Tecnol�gicas
%	e-mail: dayanne.coelho@prof.unibh.br

%====== Func�o  ======%
function fx = funcao(x)

 %fx = x^2-4;
 fx = x^3-9*x+3;